# Madhav_Store_PowerBI_Dashboard
Professional Power Bi Dashboard

Complete Power BI project using retail store sales data 

Watch tutorial video on YouTube :)
